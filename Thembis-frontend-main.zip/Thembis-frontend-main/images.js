import achatch1 from '../../Ecommerce-React/Ecommerce-add-cart-main/src/assets/images/achar1.png';
import achatch2 from '../../Ecommerce-React/Ecommerce-add-cart-main/src/assets/images/achar2.jpg';
import achatch3 from '../../Ecommerce-React/Ecommerce-add-cart-main/src/assets/images/achar3.jpg';
import achatch4 from '../../Ecommerce-React/Ecommerce-add-cart-main/src/Ecommerce-React/Ecommerce-add-cart-main/src/assets/images/achar4.jpg';
import chili1 from '../../Ecommerce-React/Ecommerce-add-cart-main/src/assets/images/chili1.png';
import chili2 from '../../Ecommerce-React/Ecommerce-add-cart-main/src/assets/images/chili2.png';
import chili3 from '../../Ecommerce-React/Ecommerce-add-cart-main/src/assets/images/chili3.png';
import chili4 from '../../Ecommerce-React/Ecommerce-add-cart-main/src/assets/images/chili4.png';


 const images = {"achatch1": achatch1, "achatch2": achatch2, "achatch3": achatch3, "achatch4": achatch4, "chili1": chili1, "chili2": chili2, "chili3": chili3, "chili4": chili4};

 export default images;
